﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace RPSLS
{
    public class Game
    {
        public HumanPlayer player1;
        public HumanPlayer player2;
        public ComputerPlayer cpu;
        public int score;
       

        //Showing main menu
        public static void ShowGameMenu()
        {
            Console.WriteLine("Welcome to Rock, Paper, Scissors, Lizard, Spock");
            Console.WriteLine("===============================================");
            Console.WriteLine("1. New Game");
            Console.WriteLine("2. Quit Game");
            Console.ReadKey();
        }

        //Showing rules of the game
        public static void ShowGameRules()
        {
            Console.WriteLine("Welcome to Rock, Paper, Scissors, Lizard, Spock");
            Console.WriteLine(" ");
            Console.WriteLine(" ");
            Console.WriteLine("The rules of the games are: ");
            Console.WriteLine(" ");
            Console.WriteLine("Rock crushes Scissors.");
            Console.WriteLine("Scissors cuts Paper.");
            Console.WriteLine("Paper covers Rock.");
            Console.WriteLine("Rock crushes Lizard.");
            Console.WriteLine("Lizard poisons Spock.");
            Console.WriteLine("Spock smashes Scissors.");
            Console.WriteLine("Scissors decapitates Lizard.");
            Console.WriteLine("Lizard eats Paper.");
            Console.WriteLine("Paper disproves Spock.");
            Console.WriteLine("Spock vaporizes Rock.");
            Console.WriteLine(" ");
            Console.WriteLine("Both players will present hand gesture at the same time.");
            Console.WriteLine("If hand gestures are the same for both players, it's a draw game.");
            Console.WriteLine("5 games will be played and the player with the higher score wins.");
            Console.ReadKey();
        }
        public void Main()
        {
            //Displaying menu intro of the game
            ShowGameMenu();

            HumanPlayer player1 = new HumanPlayer();
            // test1.Choice1();
            HumanPlayer player2 = new HumanPlayer();
            // test2.Choice2();

            int p1; int p2;
            bool b1; bool b2; bool b3; bool b4; bool b5;

            p1 = 4; //test overrides
            p2 = 2; //test overrides

            //boolean conditions must hold a boolean (mini inline if statement -- TERNARY OPERATOR)
            b1 = (p1 == 1 && (p2 == 3 || p2 == 4)); // ? true : false;
            b2 = (p1 == 2 && (p2 == 1 || p2 == 5)); // ? true : false;
            b3 = (p1 == 3 && (p2 == 2 || p2 == 4)); // ? true : false;
            b4 = (p1 == 4 && (p2 == 5 || p2 == 2)); // ? true : false;
            b5 = (p1 == 5 && (p2 == 3 || p2 == 1)); // ? true : false;

            if (p1 == p2)
            {
                Console.WriteLine("It's a draw.");
                Console.ReadKey();
            }
            else if ((b1 || b2 || b3 || b4 || b5) == true)
            {
                Console.WriteLine("Congrats player 1. YOU WIN!!!");
                Console.ReadKey();
            }
            else
            {
                Console.WriteLine("Congrats player 2. YOU WIN!!!");
                Console.ReadKey();
            }
        }
    }
}
